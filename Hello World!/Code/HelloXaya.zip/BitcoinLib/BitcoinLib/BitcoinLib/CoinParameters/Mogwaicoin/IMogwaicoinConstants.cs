﻿namespace BitcoinLib.CoinParameters.Mogwaicoin
{
    public interface IMogwaicoinConstants
    {
        MogwaicoinConstants.Constants Constants { get; }
    }
}